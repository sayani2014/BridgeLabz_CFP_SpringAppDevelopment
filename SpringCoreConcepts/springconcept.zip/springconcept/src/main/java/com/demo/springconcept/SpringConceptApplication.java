package com.demo.springconcept;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringConceptApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringConceptApplication.class, args);
	}

}
