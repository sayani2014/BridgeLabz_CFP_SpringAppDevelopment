package com.demo.springconcept;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringConceptApplicationTests {

	@Test
	void contextLoads() {
	}

}
